
var parser = function(){
	var _toolbar;
	var _href;
	var _checkCount = 0;
	var _events = {} ;
	var _widgetId;
	var _checking = 0;
	var _refreshRate = 1000;
	var _mail = {};
	var _results = {
		"rss": [],
		"address": [],
		"calendar": []
	};

	var $jq ;
	
	function getValue(pref) {
		var val;
		var key = _widgetId + "." + pref;
		try {
			val = _toolbar.getPref(key).toString();
		} catch(e) {
			
		}
		return val;
	}
		
	function setValue(pref, val) {

		var key = _widgetId + "." + pref;
		try {
			_toolbar.setPref(key, val);
		} catch(e) {
			
		}
		
	}

	
	function formatString(str){

		if(str.length>0){
			str = $jq.trim(str); //remove white space at begin and end 
			str = str.substr(0,str.length-1);
		}
		return str;

	}


	
	function stripHTML(str,obj){

		if (str){
			str = str.replace(/<br>/ig, " ");
			obj.innerHTML = str;
			str = $jq(obj).text();
		}
		return str;
	}
	

	function updateResults(count) {
		setValue("count", count); 
		if (count > 0) {
			classOn = "on";
			classOff = "off";
		} else {
			classOn = "off";
			classOff = "on";
		}
		$jq("#count").toggleClass(classOff, false);
		$jq("#count").toggleClass(classOn, true);

	}


	function dom_check(){
		var doc = _toolbar.getDocument();
		if (doc) {
			var href = doc.URL;
								
			if (_href != href) {
				_href = href;
				updateResults(0);
		
				_results = { 
					"rss":[],
					"address":[],
					"calendar":[]
				};
			
				rss_check(doc);
				microformat_check(doc);
				updateResults(_results.rss.length + _results.address.length + _results.calendar.length);
			}
		}
		_checking = 0; 
	}
	

	function rss_check(dom){

	
	
		$jq('link[type="application/rss+xml"]',dom).each(function() {
			var uiData = {
				"href": this.href
			};
			_results.rss.push(uiData); 
		});	
	}
	
	
	function microformat_check(dom) {
		try{

			var address = [];
			var count =0;

			if (typeof dom == "undefined" || typeof dom.body == "undefined" ||  dom.URL.indexOf("mapquest.com") > 0) {
				return count;
			}

			//create a dummy obj to striphtml tag and replace<br> with space. 
			var dummy_obj = dom.createElement("div");
			dummy_obj.id="container_location_div";
			dummy_obj.style.display = "none";
			var fc = dom.body.firstChild;
			dom.body.insertBefore(dummy_obj, fc);
		
			var postAddress = $jq("[itemtype='http://schema.org/PostalAddress']",dom);
			postAddress.each(function(i, el) {

				var k ;
				var schemaData = {
					"streetAddress": null,
					"addressLocality": null,
					"addressRegion": null,
					"postalCode": null,
					"addressCountry": null
				};

				var searchString = "" ;
				var addressString ="";
				for (k in schemaData) {
					if (schemaData.hasOwnProperty(k)) {
						var   htmlstring= $jq(el).find("[" + "itemprop" + "='" + k + "']").html();

						if(htmlstring && htmlstring.length > 0){
							schemaData[k] = $jq.trim(stripHTML(htmlstring,dummy_obj)); 
						}
						if(schemaData[k] && schemaData[k].length > 0){
							searchString += schemaData[k]+'+'; 
							addressString += schemaData[k]+', '; 
						}
					}
				}

				//if it is a valid format
				if (searchString.length >0){

					searchString = formatString(searchString); 
					addressString = formatString(addressString); 
					
					var url = encodeURIComponent(searchString);
					var uiData = {
						"href": "http://mapq.st/?ICID=mqtbarlocation&q=" + searchString,
						"title": addressString,
						"tooltip": addressString
					};
					
					_results.address.push(uiData);
					
				}

			});

			var adr = $jq("[class='adr']",dom);
			adr.each(function(i, el) {
				var k ;
				var schemaData = {
					"post-office-box": null,
					"street-address": null,
					"extended-address": null,
					"locality": null,
					"region":null,
					"postal-code": null,
					"country-name":null

				};
				var searchString = "" ;
				var addressString ="";

				for (k in schemaData) {
					if (schemaData.hasOwnProperty(k)) {
						var   htmlstring= $jq(el).find("[" + "class" + "='" + k + "']").html();

						if(htmlstring && htmlstring.length > 0){
							schemaData[k] = $jq.trim(stripHTML(htmlstring,dummy_obj));
						} 

						if(schemaData[k] && schemaData[k].length > 0){
							searchString += schemaData[k]+'+'; 
							addressString += schemaData[k]+', '; 
						}
					}
				}

				if (searchString.length >0){

					searchString = formatString(searchString); 
					addressString = formatString(addressString); 
					var url = encodeURIComponent(searchString);
					var uiData = {
						"href": "http://mapq.st/?ICID=mqtbarlocation&q=" + searchString,
						"title": addressString,
						"tooltip": addressString
					};

					_results.address.push(uiData);
				}		
			});

			var geo = $jq("[class='geo']",dom);
			geo.each(function(i, el) {
				var k ;
				var schemaData = {
					"latitude": null,
					"longitude": null
				};

				for (k in schemaData) {
					if (schemaData.hasOwnProperty(k)) {
						var val =  $jq(el).find("[" + "class" + "='" + k + "']").attr('title');
						if (val && val.length >0) 
							schemaData[k] = val;
						else
							schemaData[k] =$jq(el).find("[" + "class" + "='" + k + "']").text();
						schemaData[k] = $jq.trim(schemaData[k]);
					}
				}
				if (schemaData['latitude'].length > 0 && schemaData['longitude'].length>0)
				{
					var href = schemaData['latitude']+","+schemaData['longitude'] ;
					var desc = "Geo: "+ schemaData['latitude'] +", "+ schemaData['longitude'];
					var uiData = {
						"href": "http://mapq.st/?ICID=mqtbarlocation&q=" + href,
						"title": desc,
						"tooltip": desc
					};
					_results.address.push(uiData);
				}
				
			});

			var calendar =[];
			var cal = $jq("[class='vevent']",dom);
			cal.each(function(i, el) {
				var k ;
				var schemaData = {
					"summary": null,
					"location": null,
					"dtstart": null,
					"dtent": null,
					"url":null,
					"rdate": null,
					"status":null

				};

				var found = false ;

				for (k in schemaData) {
					if (schemaData.hasOwnProperty(k)) {
						var   htmlstring= $jq(el).find("[" + "class" + "='" + k + "']").html();

						if(htmlstring && htmlstring.length > 0){
							schemaData[k] = $jq.trim(stripHTML(htmlstring,dummy_obj));
						} 

						if(schemaData[k] && schemaData[k].length > 0){
							found = true;
						}
					}
				}

				if (found){
					_results.calendar.push(schemaData);
				}		
			});

			dom.body.removeChild(dummy_obj);

		} catch(e) {
			//alert("microformat check error=" + e.message + e.lineNumber);
		}
	}
	

	
	return {
	
		init: function() {
			$jq = jQuery.noConflict(true);
			
			updateResults(0);
			
			_events.load =  _toolbar.subscribe("load", "", "dom");
			_events.focus =  _toolbar.subscribe("focus", "", "dom");
		},
	
		onInitialize : function(tb) {
			_toolbar = tb;
			_widgetId = tb.widget;
			var timeout = 0;
			try {
				
				setTimeout(function() {
						parser.init();
					}, timeout);
			} catch (e) {
				alert(e.message);
			}
			
			document.body.onclick = function(event) {
				_toolbar.openPopup("results");
			}
		
			
		},        
		
		onPageLoad : function() {
			try{
				
				if (_checking === 0){
					_checking = 1;
					
					setTimeout(function() {
						try {
							dom_check();
						} catch (e) {
							alert(e.message);
						}
					}, 1000);
				}
			}catch(e){
				//alert(e);
			}
		},
		
		onLocationChange : function(uri, data) {
			try {
				if (_checking === 0){
					_checking = 1;
					
					setTimeout(function() {
						try {
							dom_check();								
						} catch (e) {
							alert(e.message);
						}
					}, 1000);
				}
				
			}catch(e){
				//alert(e);
			}
		},

		onMessage : function(sender, message, data) {
			var datastring = JSON.stringify(_results);
			_toolbar.sendMessage("parser.popup","data", datastring);
		}
	
	}
}();

function widget_onInitialize(tb) {
	parser.onInitialize(tb);
}

function widget_onPageLoad(data) {

	parser.onPageLoad();
}

function widget_onLocationChange(uri, data) {
	parser.onLocationChange(uri, data);
}

function widget_onMessage(s, m, d) {
	parser.onMessage(s, m, d);
}