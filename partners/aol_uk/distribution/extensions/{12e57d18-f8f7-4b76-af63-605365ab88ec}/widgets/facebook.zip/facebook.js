
function widget_onInitialize(tb) {
   facebook.init(tb);
}

function widget_onPageLoad(doc, data) {

	facebook.check();
}

function widget_onPrefChange(pref, data) {
	facebook.update();
}

function showHover() {
	document.getElementById("facebook_span").style.backgroundImage = "url('icon_facebook_hover.png')";
}

function resetHover() {
	document.getElementById("facebook_span").style.backgroundImage = "url('icon_facebook.png')";
}

var facebook = function() {
    var _width = 0;
	var _padding = 10; 
	var _toolbar;
	var _eventId;
	var _widgetId;
	var _tooltip;
		
	function getValue(pref) {
	
		var val;
		var key = _widgetId + "." + pref;
		try {
			val = _toolbar.getPref(key).toString();
		} catch(e) {
			alert(key + " " + e.message)
		}
		return val;
	}
	
	function setValue(pref, val) {
	
		var key = _widgetId + "." + pref;
		try {
			_toolbar.setPref(key, val);
		} catch(e) {
			alert(key + " " + e.message)
		}
		
	}
	
	function showNotificationCount() {
		var span = document.getElementById("notifications");
		var notifications = getValue("notifications");
        span.innerHTML = "";
 	    if (navigator.userAgent.indexOf("Firefox") != -1) {
			span.style.height = "24px";
	    }
		
		_toolbar.updateTooltip(_tooltip);
	}
	
	return {
		init : function(tb) {
			var widget = JSON.parse(tb.json);			
			_widgetId = widget.id;
			_tooltip = widget.tooltip;
			
			_toolbar = tb;
			
			_eventId = _toolbar.subscribe("load", "page", "testing");
			_eventId = _toolbar.subscribe("pref", _widgetId + ".notifications", "hello");
			
			document.body.onclick = function(event) {
				_toolbar.openPopup("fbqap");
			}
			setTimeout(function() {
				facebook.initFB();
			},500);
		},
		
		initFB : function() {
			alert("initFB");
			FB.init({
				appId      : '356634217775541', // App ID from the App Dashboard
				channelUrl : '//client.web.aol.com/toolbarfiles/Prod/Content/widgets/facebook/qap/channel.html', // Channel File for x-domain communication
				status     : true, // check the login status upon init?
				cookie     : true, // set sessions cookies to allow your server to access the session?
				xfbml      : true  // parse XFBML tags on this page?
			});		
			
			facebook.checkLoginStatus();
		},
		
		checkLoginStatus : function() {
			alert("checkLoginStatus");

			try {
				FB.getLoginStatus(function(response) {
					if (response.status === 'connected') {
						alert("connected!");
					} else if (response.status === 'not_authorized') {
						// user logged in, app NOT authorized
						alert("not auth'd");
					} else {
						// user NOT logged in
						alert("not connected");
					}
				});
			} catch(e) {
				alert("Error: " + e);
			}
		},
		
		check : function() {
			//getCounts();
		},
		
		update : function() {
			//showPageCounts();	
		}
	}
}();
