function extractSender(data) {

    var sender = {};
    try {
        var email = data.substr(data.lastIndexOf("<"));
        sender.addr = email.substr(1, email.lastIndexOf(">")-1) ;

        var title = data.match(/^(.+)(?=<.+>$)/)[0].split(/[\t\r\n]/)[0]; 
        
        if (title) {
            sender.title = title;
        } else {
            sender.title = sender.addr;
        }
        
    } catch(e) { }
   
    return sender;
}

var addEvent = (function () {
  if (document.addEventListener) {
    return function (el, type, fn) {
      if (el && el.nodeName || el === window) {
        el.addEventListener(type, fn, false);
      } else if (el && el.length) {
        for (var i = 0; i < el.length; i++) {
          addEvent(el[i], type, fn);
        }
      }
    };
  } else {
    return function (el, type, fn) {
      if (el && el.nodeName || el === window) {
        el.attachEvent('on' + type, function () { return fn.call(el, window.event); });
      } else if (el && el.length) {
        for (var i = 0; i < el.length; i++) {
          addEvent(el[i], type, fn);
        }
      }
    };
  }
})();


function getDataObject(res) {
    var data = {}, obj;   
    if (typeof res === "string") {            
        try {
            obj = JSON.parse(res);            
        } catch (e) { }
    } else {
        obj = res;
    }
    if (obj) {
        data = obj.response.data;
    }
    return data;
}

var AOLMail = {
   
    apiUrl: "https://api.mail.aol.com/mail/",
   
    countLimit: 75,
    
    getMessageList: function() {
        this.__callMethod ("newMailList", this.countLimit);
    },

    getMessageCount: function() {
        this.__callMethod( "newMailCount", 0);
    },

    __callMethod: function (methodName, limit) {
 
        var __url;

        __url = AOLMail.apiUrl + methodName + "?bearer_token="+MailApp.token()+"&f=json";
        
        if (limit > 0) {
            __url += "&items=" + limit;
        } 
        MailApp.getData(__url, methodName);     
          
    }   
};


var MailAggregator = {
    updateBadge : function(){
        AOLMail.getMessageCount();
    }, 

    updateMessageList : function() {
       AOLMail.getMessageList();
    },


    processMessageCount : function(data, params) {
        var count = 0;
        try {
            for (var i = 0; i < data.mailFolderCount.mailFolderData.mailFolderType.length; i+=1) {
                count +=  data.mailFolderCount.mailFolderData.mailFolderType[i].count;
            }
        } catch (e) {
             
        }
        return count;
    },


    processMessageList : function(data, params) {
      

        var messageList = data.mailList.messageList;
        var messages = [];
        try {
            $.each(messageList, function (index, folder) {
                $.each(folder.messages, function(fldIndex, message) {
                    var dateOrTime = getFormattedDate(new Date(message.sentOn), true);
                    var sender = extractSender(message.sender);
                    messages.push(
                        { id: fldIndex, title: sender.title, email: sender.addr, description: message.subject, href: message.messageLink, extra: dateOrTime});
                });
            
            });
        } catch (e) {
           
        }  
        return messages;  
    },

    getCurrentUser : function() {
         AuthAPI.getUserId();
    }
};

var AuthAPI = {

      /**
     * AOL OAuth API
     */
    API_URI: "https://api.screenname.aol.com/auth/",
    REDIRECT_LOGIN_URI : "https://client.web.aol.com/toolbarfiles/Prod/Content/widgets/aolmail/auth/data.html?",
    /**
     * Dev ID and scope to provide to OAuth API
     */
    DEV_ID: "ao15ToILDSKh7PDj",
    SCOPE : "openMailGeneral",
    EXTENSION_NAME: "mail",

    SIGNIN_WIDTH : "550px",
    SIGNIN_HEIGHT : "390px",

    LOGOUT_URI : "https://client.web.aol.com/toolbarfiles/Prod/Content/widgets/aolmail/auth/logout.html",
   
    
    getSigninUrl : function() {
        return this.API_URI + "authorize" + "?ext=" + this.EXTENSION_NAME + "&client_id=" + this.DEV_ID + "&redirect_uri=" + encodeURIComponent(this.REDIRECT_LOGIN_URI) +"&response_type=token&scope=" + this.SCOPE + "&supportedIdType=aol&autoclose=true";
    },

    logout: function(language) {
       
        var user = MailApp.getValue("user");
        var token = MailApp.token();
        var url = AuthAPI.API_URI + "logout?" +
                    "&a=" + token +
                    "&devId=" + this.DEV_ID +
                    "&s=" +  user +
                    "&f=json" +
                    "&succUrl=" + encodeURIComponent(this.LOGOUT_URI);

       MailUI.showSignout(url);
    },

    getUserId: function(successCallback, failureCallback) {
        var token = MailApp.token();
        var url = this.API_URI + "getUserData?f=json&access_token="+token;
        MailApp.getData(url, "userId");   
    }
};

var MailUI = {



    showSignout : function(url) {
    
        var div = document.createElement("div");
        div.id = "logout";
        var iframe = document.createElement("iframe");
 

        iframe.top = "1000px";
        iframe.width = "1px";
        iframe.height = "1px";      
        div.appendChild(iframe);
        document.body.appendChild(div);
        iframe.src = url;
        
    },


    showSignin : function(delay) {
        
        $("#container").hide();

        setTimeout(function() {
            var sns = document.createElement("div");
            sns.id = "sns";
            var iframe = document.createElement("iframe");
            iframe.id = "signin";

            sns.appendChild(iframe);
            document.body.appendChild(sns);

            iframe.src = AuthAPI.getSigninUrl();
            iframe.width = AuthAPI.SIGNIN_WIDTH;
            iframe.height = AuthAPI.SIGNIN_HEIGHT;
        } , delay);
    },

    showTip : function(evt) {
         var item = evt ? evt.target : window.event.srcElement;
    },

    openLink : function(evt) {
        var item = evt ? evt.target : window.event.srcElement;
        var url = item.getAttribute("data-href");
        MailApp.openUrl(url, 2);
        return false;
    },

    updateUser : function(user){
        MailApp.setValue("user", user);
        $("#username").html(user);
    },

    updateCount : function(count) {
        MailApp.setValue("count", count);
        $("#mailcount").html(count + " New");
    },

    updateList : function(messages) {
       
        var i = 0, msg;
        var ul = document.getElementById("messagelist");
        ul.innerHTML = "";
        for ( ; i < messages.length; i+=1) {

            try {
                msg = messages[i];
                var li = document.createElement("li");
                var item = document.createElement("div");
                var dt = document.createElement("span");
                var sender = document.createElement("span");
                var message = document.createElement("span");
                var br = document.createElement("br");
                var div = document.createElement("div");

                item.className = "message";

                dt.setAttribute("data-href", msg.href);
                dt.className = "datesent";

                sender.setAttribute("data-href", msg.href);
                sender.className = "sender";

                message.setAttribute("data-href", msg.href);
                message.className = "subject";

                div.className = "dotted_line whitespace";

                li.setAttribute("data-href", msg.href);
                
                addEvent(li, "click", function(e){
                     MailUI.openLink(e);
                });

                
                li.id = msg.id;

                dt.innerHTML = msg.extra;
                sender.innerHTML = shorten(msg.title.replace(/\s+/g, ' '), 80);
                
                sender.title = msg.email;
                message.innerHTML = shorten(msg.description, 75);
                li.title = msg.description;

                item.appendChild(sender);
                item.appendChild(br);
                item.appendChild(message);
                item.appendChild(dt);
                li.appendChild(item);
                li.appendChild(div);
                
                ul.appendChild(li);
            } catch (e) {
                
            }
        }

        $("#messages").niceScroll({cursorcolor:"#9a9a9a", horizrailenabled:false});
    }
};



var MailApp = function() {
	
	var _ie = -1;
    var _toolbar;
    var _widgetId;
    var _token;
    var _tokenExpiresIn;
    var _tokenType;
    var LOGOUT_URL = "./index.html";
    var _lang = "en";
    var COMPOSE_URL = "http://mail.aol.com/compose-message.aspx";
    var SHOWALL_URL = "http://mail.aol.com";
    function getRequestParameter(url, name){
        var y = "";
        if(name=(new RegExp('[?&#]'+encodeURIComponent(name)+'=([^&]*)')).exec(url)) {
            y = decodeURIComponent(name[1]);
        }     
        return y;
    }




return {

    debug : function(msg) {
        _toolbar.log(msg);
    },


    ready : function() {
        
        $("#container").hide();

        addEvent(window, "message", function(evt) {

            if (evt.data == "logout.success") {
                $("#logout").remove();
                MailUI.showSignin(200);
            }
        });
            
        $("#signout").click(function() {
            MailApp.logout();
        });

        $("#showall").click(function() {
            MailApp.showall();
        });

        $("#logo").click(function() {
            MailApp.showall();
        });

        $("#newmail").click(function() {
            MailApp.compose();
        });
        
        MailUI.showSignin(10);
    },

    onInitialize : function(tb) {
        if (tb) {
            _toolbar = tb;
            _widgetId = tb.widget;
			_ie = getIEVersion(); 
			var appEngine = 0;
            if (typeof _toolbar.appEngine != "undefined") {
                appEngine = _toolbar.appEngine;
            }
			// show the old qap if the toolbar does not support our app
			if (appEngine < 2) {
                _toolbar.resizeWindow(292,336);
                var oldqap = "qaphost:yourminisaolmail.html";
                var qaphost = _toolbar.getProp("widgets.qaphost").replace("{wid}", _widgetId).replace("//qap", "/aolmail/qap");
				var url = oldqap.replace("qaphost:", qaphost +"/") + "?update=true";
                window.location = url;
            }
        }
    },

    onToken: function(url) {  

        var xuri = url.replace(/#/g, "");

        var parsedUri = parseUri(xuri);
        if (parsedUri) {
            _token = parsedUri.queryKey.access_token;
            _tokenExpiresIn = parsedUri.queryKey.expires_in;
            _tokenType = parsedUri.queryKey.token_type;

            MailAggregator.getCurrentUser();
            MailAggregator.updateBadge();
            MailAggregator.updateMessageList();
        }
    },

    setLanguage : function(v) {
        _lang = v;
    },

    getLanguage : function() {
        return _lang;
    },

    getValue : function(pref) {
        var val;
        var key = _widgetId + "." + pref;
        try {
            val = _toolbar.getPref(key).toString();
        } catch(e) {
            
        }
        return val;
    },

    setValue : function(pref, val) {
        var key = _widgetId + "." + pref;
        try {
            _toolbar.setPref(key, val.toString());
        } catch(e) {
          
        }
    },

    token : function() {
       return _token;
    },

    login : function() {
        return true;
    },


    logout : function() {
        AuthAPI.logout(_lang);       
    },

    recordEvent : function(name, m1, m2) {
        // metrics
    },

    openUrl : function(url, target) {
        _toolbar.openUrl(url, target, "");
    },

    compose : function() {        
        if (_ie != -1) {
            window.open(COMPOSE_URL);
        } else {
            this.openUrl(COMPOSE_URL, 1);
        }
        _toolbar.closeWindow();
    },

    showall : function() {
        this.openUrl(SHOWALL_URL, 2);
        _toolbar.closeWindow();
    },

    getData : function(url, params) {

        if (typeof _toolbar.getDataEx != "undefined") {
            return _toolbar.getDataEx(url, "", params, "");    
        } else {
            return _toolbar.getData(url);
        }
    },

    onData : function(res, params) {

        var data = getDataObject(res);          
        if (data) {
           
            if (data.mailFolderCount) {
                var count = MailAggregator.processMessageCount(data);
                MailUI.updateCount(count);
            } else if (data.mailList) {            
                var messages = MailAggregator.processMessageList(data);
                MailUI.updateList(messages);
            } else if (data.userData) {
                 MailUI.updateUser(data.userData.displayName);
            }
        } else {
			MailUI.showSignin(200);
		}    
         
    },


    onMessage : function(sender, message, data) {

       if (message == "login") {
            $("#container").show();
            $("#sns").remove();
            MailApp.onToken(data);
       }
    }
}


}();

