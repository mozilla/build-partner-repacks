var app = function(){
    var _toolbar;
    var _eventIid ;
	var _widgetId;


 return {
        onInitialize : function(tb) {
            _toolbar = tb;
			_widgetId = tb.widget;
        }
    }
}();