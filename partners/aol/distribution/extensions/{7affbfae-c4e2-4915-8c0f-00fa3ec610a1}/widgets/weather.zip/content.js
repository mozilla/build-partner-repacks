var app = function(){
    var _toolbar;
    var _checkCount = 0;
    var _eventIid ;
	var _widgetId;


	function check() {
	
	}

 return {
        onInitialize : function(tb) {
            _toolbar = tb;
			_widgetId = tb.widget;
			_eventId = tb.subscribe("load", "", "");
		  
        },        
		
		onPageLoad : function(doc, data) {
			
			alert(doc);
		},
			
		onMessage : function(sender, message, data) {
			if (message == "pinit") {
				doPinit();
			}
		},		
		
		onPrefChange : function(pref, data) {
			
		}
        
    }
}();