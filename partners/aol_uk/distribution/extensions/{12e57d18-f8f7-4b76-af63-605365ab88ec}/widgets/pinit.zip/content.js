var app = function(){
    var _toolbar;
    var _checkCount = 0;
    var _eventIid ;
	var _widgetId;


	function doPinit() {
		var doc = _toolbar.getDocument();
		var e = doc.createElement('script');
		e.setAttribute('type', 'text/javascript');
		e.setAttribute('charset', 'UTF-8');
		e.setAttribute('src', 'http://assets.pinterest.com/js/pinmarklet.js?r=' + Math.random() * 99999999);
		doc.body.appendChild(e);	
		doc.body.focus();
	}

 return {
        onInitialize : function(tb) {
            _toolbar = tb;
			_widgetId = tb.widget;
		  
        },        
		
		onPageLoad : function(doc, data) {
			
			
		},
			
		onMessage : function(sender, message, data) {
			if (message == "pinit") {
				doPinit();
			}
		},		
		
		onPrefChange : function(pref, data) {
			
		}
        
    }
}();