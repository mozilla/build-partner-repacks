function widget_onInitialize(tb) {
   calendar.init(tb);
}


function widget_onPrefChange(pref, data) {

	calendar.update();
}

function showHover() {
	document.getElementById("calendar_left_edge").style.backgroundImage = "url('chiclet_left_calendar_hover.png')";
	document.getElementById("calendar_span").style.backgroundImage = "url('chiclet_tile_calendar_hover.png')";
	document.getElementById("calendar_right_edge").style.backgroundImage = "url('chiclet_right_calendar_hover.png')";
}

function resetHover() {
	document.getElementById("calendar_left_edge").style.backgroundImage = "url('chiclet_left.png')";
	document.getElementById("calendar_span").style.backgroundImage = "url('chiclet_tile.png')";
	document.getElementById("calendar_right_edge").style.backgroundImage = "url('chiclet_right.png')";
}


var calendar = function() {
    var _width = 0;
	var _padding = 4; 
	var _toolbar;
	var _eventId;
	var _widgetId;
	var _tooltip;
	var _lastDate = 0;
	
	function getValue(pref) {
	
		var val;
		var key = _widgetId + "." + pref;
		try {
			val = _toolbar.getPref(key).toString();
		} catch(e) {
			alert(key + " " + e.message)
		}
		return val;
	}
	
	function setValue(pref, val) {
	
		var key = _widgetId + "." + pref;
		try {
			_toolbar.setPref(key, val);
		} catch(e) {
			alert(key + " " + e.message)
		}
		
	}

		
	var _months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
	function showDate() {
		var diff = false;
		var timeNow = new Date();
		var lastTime = getValue("timestamp");
		var calendarMonth = document.getElementById("calendar_month");
		var calendarOverlay = document.getElementById("calendar_span_overlay");
		var calendarDay = document.getElementById("calendar_day");
		var overlayLeftEdge = 0;
		var textLeftEdge = 0;
		var resizeWidth = 0;
		var width = 0;
		
		if (lastTime != timeNow.getTime()) {
			setValue("timestamp", timeNow.getTime());
			
			var mm = _months[timeNow.getMonth()];
			var dd = timeNow.getDate().toString();
			var span = document.getElementById("calendar_span");
			var month = document.getElementById("calendar_month");
			month.innerHTML = mm.substring(0,3);
			var day = document.getElementById("calendar_day");
			day.innerHTML = dd;
			
			if (typeof _tooltip != "undefined") {
				_toolbar.updateTooltip(_tooltip);
			}
			
			//resize
			if(navigator.userAgent.indexOf("Mac") != -1) {
				calendarDay.style.height = "20px";
				calendarOverlay.style.top = "1px";
				calendarDay.style.top = "2px";
				textLeftEdge = -1;
			} else if(navigator.userAgent.indexOf("MSIE 9") != -1) {		
				calendarMonth.style.top = "0px";
				calendarMonth.style.left = "0px";
				calendarOverlay.style.top = "1px";
				calendarDay.style.top = "2px";
				overlayLeftEdge = -5;
				textLeftEdge = -1;
				resizeWidth = 5;
			} else if(navigator.userAgent.indexOf("NT 5.1") != -1) {		
				if(navigator.userAgent.indexOf("MSIE") != -1) { 
					calendarMonth.style.top = "0px";
					calendarMonth.style.left = "0px";
					calendarOverlay.style.top = "0px";
					calendarDay.style.fontSize = "12px";
					calendarDay.style.top = "1px";
					overlayLeftEdge = -8;
					textLeftEdge = 1;
					resizeWidth = 5;
				} else {
					calendarDay.style.fontSize = "12px";
					overlayLeftEdge = 0;
					textLeftEdge = 1;
					resizeWidth = 0;
				}
			}

			if(dd < 10) {
				width = month.clientWidth + day.clientWidth + 12 + resizeWidth;
				overlayLeftEdge = overlayLeftEdge + ((width + 10) - 22);
				textLeftEdge = textLeftEdge + overlayLeftEdge + 6;
			} else {
				width = month.clientWidth + day.clientWidth + 5 + resizeWidth;				
				overlayLeftEdge = overlayLeftEdge + ((width + 10) - 22);
				textLeftEdge = textLeftEdge + overlayLeftEdge + 2;
			}
			calendarOverlay.style.left = overlayLeftEdge + "px";
			calendarDay.style.left = textLeftEdge + "px";
			span.style.width = width + "px";
			_toolbar.resize(width + 10, 28);
	
			diff = true;
		}
		return diff;
	}
	
	
	
	
	return {
		init : function(tb) {
		
		
			_toolbar = tb;
			_widgetId = tb.widget;
			if (typeof JSON != "undefined") {
				_tooltip = JSON.parse(tb.json).tooltip;
			}
			_eventId = _toolbar.subscribe("pref", _widgetId + ".day", "");
				
			
			document.body.onclick = function(event) {
				_toolbar.openPopup("monthview");
			}
		
			calendar.check();
		
			
		},
		
		update : function() {
			showDate();	
			
			
		},
		
		check : function() {
			showDate();
			var interval;
			var timeNow = new Date();
			var hourDif = 23 - timeNow.getHours();
			
			if (hourDif == 0) {
				var minDif =  59 - timeNow.getMinutes();
				
				if (minDif == 0) {
					interval = 2000;
				} else {
					interval = 30 * 1000;
				}
			} else if (hourDif == 1) {
				interval = 30 * 60 * 1000;
			} else {
				interval = (hourDif - 1) * 60 * 1000;
			} 
	
			setTimeout(function() {
				calendar.check();
				}, interval);				
		}
	}
}();
