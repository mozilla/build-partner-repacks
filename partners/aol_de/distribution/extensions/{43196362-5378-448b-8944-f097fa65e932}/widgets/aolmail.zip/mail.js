var app = function(){
    var _toolbar;
    var _checkCount = 0;
    var _eventIid ;
	var _widgetId;
	var _lastCheck = 0;
	var _refreshRate = 1000;
	var _mail = {};
	
	function getValue(pref) {
	
		var val;
		var key = _widgetId + "." + pref;
		try {
			val = _toolbar.getPref(key).toString();
		} catch(e) {
			alert(key + " " + e.message)
		}
		return val;
	}
	
	function setValue(pref, val) {
	
		var key = _widgetId + "." + pref;
		try {
			_toolbar.setPref(key, val);
		} catch(e) {
			alert(key + " " + e.message)
		}
		
	}


	function canRequest(){
		var ok = false;
		var timeNow = new Date();
		if ((timeNow - _lastCheck) > _refreshRate) {
			ok = true;
        }  			 
		return ok ;
	}
		
	

	
	function check() {
		if (navigator.platform.indexOf('Mac') == -1 ){
			try {
				if (_checkCount == 0) {
					var newName = false;
					var screenName = _mail.getScreenName();
					var address = getValue("address");
					if (screenName != "") {
						if (screenName != address) {
							setValue("address", screenName);
							// trim the domain
							var pos = screenName.indexOf("@");
							if (pos > 0) {
								user = screenName.substring(0, pos);
							} else {
								user = screenName;
							}
							setValue("user", user);
							newName = true;
						}	
						if (newName || canRequest()) {
							_lastCheck  = new Date();
							var mailCount = _mail.getMailCount(screenName);
							if (mailCount < 0) mailCount = 0;						
							_refreshRate = _mail.getRefreshRate() * 1000; //millisecond						
							setValue("count", mailCount);
							setValue("imagelist.layout", (mailCount == 0) ? "empty" : "open"); 
						}
					}						
				} 
				
				if (++_checkCount == 5) {
					_checkCount = 0;     
				}
			} catch(e) {
				alert('aolmail check '  +e.message);
			}
		}
		
    }
	

	
    return {
        onInitialize : function(tb) {

            _toolbar = tb;
			_widgetId = tb.widget;
		    _eventId =  _toolbar.subscribe("load", "", "mailcounts");			
			_mail = _toolbar.getObject("mail");
			setTimeout(function() {
				check();
				}, 1000);
        },        
		
		onPageLoad : function(uri, data) {
			check();
		},
			
		onMessage : function(sender, message, data) {
			
		},
		
		
		onPrefChange : function(pref, data) {
			
		}
        
    }
}();



