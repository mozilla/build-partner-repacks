var maxDigits = 3;

function widget_onInitialize(tb) {
   surfometer.init(tb);
}

function widget_onPageLoad(doc, data) {

	surfometer.check();
}

function widget_onPrefChange(pref, data) {
	surfometer.update();
}

function showHover() {
	var i;
	var digitID;

	document.getElementById("surf_left_edge").style.backgroundImage = "url('chiclet_left_surfometer_hover.png')";
	document.getElementById("surf_right_edge").style.backgroundImage = "url('chiclet_right_surfometer_hover.png')";
	for (i = maxDigits-1; i >= 0; i--) {
		digitID = "digit_" + i;
		document.getElementById(digitID).style.backgroundImage = "url('counter_hover.png')";
	}
	
}

function resetHover() {
	var i;
	var digitID;
	
	document.getElementById("surf_left_edge").style.backgroundImage = "url('chiclet_left.png')";
	document.getElementById("surf_right_edge").style.backgroundImage = "url('chiclet_right.png')";
	for (i = maxDigits-1; i >= 0; i--) {
		digitID = "digit_" + i;
		document.getElementById(digitID).style.backgroundImage = "url('counter.png')";
	}
}

var surfometer = function() {
    var _width = 0;
	var _padding = 10; 
	var _toolbar;
	var _eventId;
	var _widgetId;
	var _tooltip;
	var firstSet = true;
	var DAYDIF = 0x0001;
	var WEEKDIF = 0x0002;
	var MONTHDIF = 0x0004;
	var YEARDIF = 0x0008;
		
	function getValue(pref) {
	
		var val;
		var key = _widgetId + "." + pref;
		try {
			val = _toolbar.getPref(key).toString();
		} catch(e) {
			alert(key + " " + e.message)
		}
		return val;
	}
	
	function setValue(pref, val) {
	
		var key = _widgetId + "." + pref;
		try {
			_toolbar.setPref(key, val);
		} catch(e) {
			alert(key + " " + e.message)
		}
		
	}
	
	function incrementValue(pref) {
		var val = getValue(pref);
		var count = Math.round(val) + 1;
		setValue(pref, count.toString());
	}
	
	
	function showPageCounts() {
		
		var ff = false;
		var span = document.getElementById("counter");
        span.innerHTML = "";
 	    if (navigator.userAgent.indexOf("Firefox") != -1) {
			span.style.height = "24px";
	    }
		
		var monthly = getValue("monthly").toString();
		var digits = monthly.length;
		var val = new String("");
		for (i = digits - 1; i >= 0; i--) {
			val +=  monthly.charAt(i);
		}

		if (digits > 3 && digits <= 5) {
			maxDigits = 5;
		}
		if (digits >  5) {
			maxDigits = 7;
		}
		var width = 0;
		var num;
		var html = "";
		for (i = maxDigits-1; i >= 0; i--){
			
			// draw the 
			if (i >= digits) {
				num = "0";			
			}
			else {
				num  = val.charAt(i);
			}
			var div = document.createElement("div");
			div.className = "digit";
			div.id = "digit_" + i;
			div.innerHTML = num;
			span.appendChild(div);
			width += div.clientWidth;
		}
		span.style.width = width + "px";
		width += _padding;
		if (_width != width) {
            _toolbar.resize(width, span.clientHeight);
            _width = width;
        }        
		if (_tooltip) {
			_toolbar.updateTooltip(_tooltip);
		}
	}
	
	
	function getActiveFlag() {		
		
		
		var ly = getValue("yearstamp");
		var lm = getValue("monthstamp");
		var ld = getValue("daystamp");
		
		var lastYear = ly ? ly : 0;
		var lastMonth = lm ? lm : -1;
		var lastDate = ld ? ld : -1;
		
		if(ly != 0) {
			firstSet = false;
		}
		
		var timeNow = new Date();

		// the last check time is stored in three vals that work together
		var lastVal = lastYear;
		
		var changeFlag;
		
		if (lastVal == 0) {
			//set all
			changeFlag = (YEARDIF | MONTHDIF | DAYDIF | WEEKDIF);
		}
		else {
			
			// now check to see if anything has changed

			if (timeNow.getFullYear() > lastYear) {
				// new year everything changes (except day of week)
				changeFlag = (YEARDIF | MONTHDIF | DAYDIF);
			}
			else if (timeNow.getFullYear() == lastYear) {
				// same year
				if (timeNow.getMonth() > lastMonth) {   
					changeFlag = (MONTHDIF | DAYDIF);
				}
				else if (timeNow.getMonth() == lastMonth) {   
					// same month
					if (timeNow.getDate() > lastDate) { 
						changeFlag = DAYDIF;
					}
				}
			}
		
			// do a separate calculation to determine if we are in a different week		
			// get the date of the last sunday of each if they are different then the week has changed
			if (changeFlag){
		        
				var days = 1000*60*60*24;
		        
				var x = new Date();
				x.setFullYear(lastYear,lastMonth,lastDate);
				var t = x.getTime();

				var d = new Date();
				d.setFullYear(timeNow.getFullYear(),timeNow.getMonth(),timeNow.getDate());
				var t2 = d.getTime();
				
				t -= (x.getDay()*days);
				t2 -= (d.getDay()*days);
		
				x.setTime(t);
				d.setTime(t2);
		    	
				if(x < d){
					changeFlag |= WEEKDIF;
				}				
			}		
		}

		if (changeFlag) {
			//// something has changed - record the time	
			setValue("yearstamp", timeNow.getFullYear());
			setValue("monthstamp", timeNow.getMonth());
			setValue("daystamp", timeNow.getDate());
		}    		
		return changeFlag;
	}
	
	
	function getCounts() {
		try {
		
			var activeFlag = getActiveFlag();
			
			if (activeFlag & DAYDIF) {
				// the day has changed - see if there are others
				// we can't have the others without a day change			    
				setValue("daily", "1");
			    
				if (activeFlag & WEEKDIF) {   
					setValue("weekly", "1");
				}
				if (activeFlag & MONTHDIF) {
					
					if(!firstSet) {
						var monthTotal = getValue("monthly");
						setValue("prevmonth", monthTotal ? monthTotal : "0");
					}
					
					setValue("monthly", "0");

					if (activeFlag & YEARDIF)
					{   //debugMsg("activeFlag " + activeFlag);
						setValue("yearly", "1");
					}
				}
			} else {
				incrementValue("daily");
//				incrementValue("monthly");
				incrementValue("weekly");
				incrementValue("yearly");
			}
		} catch(e) {
			alert(e.message);
		}
	}
	
	
	return {
		init : function(tb) {
			_toolbar = tb;
			_widgetId = tb.widget;
			if (typeof JSON != "undefined") {
				_tooltip = JSON.parse(tb.json).tooltip;
			}
			_eventId = _toolbar.subscribe("load", "page", "testing");
			_eventId = _toolbar.subscribe("pref", _widgetId + ".monthly", "hello");
			
			this.update();
			
			document.body.onclick = function(event) {
				_toolbar.openPopup("surfqap");
			}
			
		},
		
		check : function() {
			getCounts();
			incrementValue("monthly");			
			incrementValue("total");
		},
		
		update : function() {
			showPageCounts();	
		}
	}
}();
