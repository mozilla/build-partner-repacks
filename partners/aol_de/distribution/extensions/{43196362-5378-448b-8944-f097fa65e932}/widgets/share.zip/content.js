var app = function(){
    var _toolbar;
    var _checkCount = 0;
    var _eventIid ;
	var _widgetId;

	function widget_onInitialize(tb) {
		_toolbar = tb;
		_widgetId = tb.widget;	   
	}

	function widget_onPageLoad(doc, data) {
		share.showURL(doc);
	}

	function widget_onPrefChange(pref, data) {
	}	
	
	return {
		init : function(tb) {
			_toolbar = tb;
			_widgetId = tb.widget;
			_eventId = _toolbar.subscribe("load", "page", "testing");
			
			this.update();
			
			document.body.onclick = function(event) {
				_toolbar.openPopup("surfqap");
			}
			
		},
		
		check : function() {
			getCounts();
			incrementValue("monthly");			
			incrementValue("total");
		},
		
		update : function() {
			showPageCounts();	
		}
	}	
}();