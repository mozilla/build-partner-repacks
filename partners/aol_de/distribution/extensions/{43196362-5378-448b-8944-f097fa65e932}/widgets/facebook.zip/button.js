
function widget_onInitialize(tb) {
   facebook.init(tb);
}

function widget_onPageLoad(doc, data) {

	facebook.check();
}

function widget_onPrefChange(pref, data) {
	facebook.update();
}

function showHover() {
	document.getElementById("facebook_span").style.backgroundImage = "url('icon_facebook_hover.png')";
}

function resetHover() {
	document.getElementById("facebook_span").style.backgroundImage = "url('icon_facebook.png')";
}

function initFB() {

	FB.init({
		appId      : '356634217775541', // App ID from the App Dashboard
		channelUrl : '//client.web.aol.com/toolbarfiles/Prod/Content/widgets/facebook/channel.html', // Channel File for x-domain communication
		status     : true, // check the login status upon init?
		cookie     : true, // set sessions cookies to allow your server to access the session?
		xfbml      : true,  // parse XFBML tags on this page?
		frictionlessRequests : true
	});		
	setTimeout(function() {checkFBLoginStatus()},2000);
}

function checkFBLoginStatus() {

	try {
		alert('check');
		FB.getLoginStatus(function(response) {
			alert(response.status);		
			
		},true);
	} catch(e) {
		alert("Error: " + e);
	}
}

			
var facebook = function() {
    var _width = 0;
	var _padding = 10; 
	var _toolbar;
	var _eventId;
	var _widgetId;
	var _tooltip;
		
	function getValue(pref) {
	
		var val;
		var key = _widgetId + "." + pref;
		try {
			val = _toolbar.getPref(key).toString();
		} catch(e) {
			alert(key + " " + e.message)
		}
		return val;
	}
	
	function setValue(pref, val) {
	
		var key = _widgetId + "." + pref;
		try {
			_toolbar.setPref(key, val);
		} catch(e) {
			alert(key + " " + e.message)
		}
		
	}
	
	function showNotificationCount() {
		var span = document.getElementById("notifications");
		var notifications = getValue("notifications");
        span.innerHTML = "";
 	    if (navigator.userAgent.indexOf("Firefox") != -1) {
			span.style.height = "24px";
	    }
		
		_toolbar.updateTooltip(_tooltip);
	}
	
	return {
		init : function(tb) {
			_toolbar = tb;
			_widgetId = tb.widget;
			if (typeof JSON != "undefined") {
				_tooltip = JSON.parse(tb.json).tooltip;
			}
			
			
			_eventId = _toolbar.subscribe("load", "page", "testing");
			_eventId = _toolbar.subscribe("pref", _widgetId + ".notifications", "hello");
			
			document.body.onclick = function(event) {
				_toolbar.openPopup("fbqap");
			}
			setTimeout(function() {
				initFB();
			},500);
		},
		
		check : function() {
			//getCounts();
		},
		
		update : function() {
			//showPageCounts();	
		},
		
		
		set : function(f,v) {
			setValue(f,v);
		}
	}
}();
