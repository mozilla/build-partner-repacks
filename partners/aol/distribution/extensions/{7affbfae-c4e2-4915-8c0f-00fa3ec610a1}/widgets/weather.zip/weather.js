

function widget_onInitialize(obj) {
	weather.init(obj);	
}

function widget_onPageLoad(uri, data) {
	weather.check();
}

function widget_onPrefChange(pref, data) {
	weather.fetch();
	weather.update();
}


// called after we request the toolbar to fetch the feed data
function widget_onData(data, params) {
	weather.parse(data, params);				
	weather.update();
}

function showHover() {
	document.getElementById("weather_left_edge").style.backgroundImage = "url('chiclet_left_weather_hover.png')";
	document.getElementById("weather_span").style.backgroundImage = "url('chiclet_tile_weather_hover.png')";
	document.getElementById("weather_right_edge").style.backgroundImage = "url('chiclet_right_weather_hover.png')";
}

function resetHover() {
	document.getElementById("weather_left_edge").style.backgroundImage = "url('chiclet_left.png')";
	document.getElementById("weather_span").style.backgroundImage = "url('chiclet_tile.png')";
	document.getElementById("weather_right_edge").style.backgroundImage = "url('chiclet_right.png')";
}


var  weather = function() {

	var _toolbar;
	var _widgetId = 0
	var _count = -1;
	var _events = [];
	var _eventID;
	var _lastUpdate;

	function getValue(pref) {
	
		var key = _widgetId + "." + pref;
		var val = _toolbar.getPref(key);
		return val.toString();
	}
	function setValue(pref, val) {
	
		var key = _widgetId + "." + pref;
		_toolbar.setPref(key, val);
	}
	
	function getWeatherData() {
		var lid = getValue("locationid");
		var url = getValue("url") + lid;
		_toolbar.getData(url);
		var timeNow = new Date();
		_lastUpdate = timeNow.getTime();
		
	}

	return {
	
		init : function(tb) {
			_widgetId = tb.widget;
			_toolbar = tb;
				
			_eventId = _toolbar.subscribe("load", "page", "testing");
			_eventId = _toolbar.subscribe("pref", _widgetId + ".locationid", "hello");
			_eventId = _toolbar.subscribe("pref", _widgetId + ".degrees", "hello");
			
			document.body.onclick = function(event) {
				_toolbar.openPopup("forecast");
			}
			
			weather.fetch();			
		},
		
		fetch : function() {
			getWeatherData();	
		},
		
		parse : function(data, params) {
		
			var xml;
		
			if (window.DOMParser) {
				var parser = new DOMParser();
				xml = parser.parseFromString(data,"text/xml");
			} else { // Internet Explorer
				xml = new ActiveXObject("Microsoft.XMLDOM");
				xml.async = false;
				xml.loadXML(data);
			}  
	
			if (xml) {
				var skycode = xml.getElementsByTagName("skyCode")[0].childNodes[0].nodeValue;
				var dn = "";
				
				
				if (parseInt(skycode) != 44) {
					dn = xml.getElementsByTagName("dayOrNight")[0].childNodes[0].nodeValue; // not night icon for "not available icon"
					if (dn=="D") {
						dn ="";
					} else {
						dn="_n";
					}
				}
				
				var degF = xml.getElementsByTagName("tempF")[0].childNodes[0].nodeValue;
				var degC = xml.getElementsByTagName("tempC")[0].childNodes[0].nodeValue;
				var city = xml.getElementsByTagName("cityName")[0].childNodes[0].nodeValue;
				var statecode = "" ;
				if (xml.getElementsByTagName("stateCode")[0].childNodes[0]){
					statecode = xml.getElementsByTagName("stateCode")[0].childNodes[0].nodeValue;
				} else {
					statecode = xml.getElementsByTagName("cntryCode")[0].childNodes[0].nodeValue;
				}
				var skydesc = xml.getElementsByTagName("skyDesc")[0].childNodes[0].nodeValue;
				
				var tooltip = city + " , " + statecode + " : " + skydesc;
		
				_toolbar.updateTooltip(tooltip);
				setValue("condition", skycode + dn);
				setValue("degf", degF);
				setValue("degc", degC);
				
				weather.update();
			}			
		},
		
		update : function(){
			var code = getValue("condition");
			var deg = getValue("degrees");
			var temp = getValue("deg" + deg.toLowerCase());	
			document.getElementById("condition").style.backgroundImage = "url(images/"+code + ".png)";				
			document.getElementById("temperature").innerHTML = temp + "&deg;" + deg;		
		},
	
		check : function() {
			_count++;
			if (_count == 0) {					
			
				var lasttime = parseInt(getValue("lastupdate"));
				var timeNow = new Date();
				var elapsed = ((parseInt(timeNow.getTime()) - _lastUpdate)/(1000*60))%30; // time in half hour
				if (elapsed > 1) {
					getWeatherData();
				}
				weather.update();
			} else if (_count == 5) {
				_count = -1;				
			}
		},
		
		openQAP : function(event) {
			
			_toolbar.doCommand("weather.forecast");
		}
	}


}();

// wait for the page to render
$(document).ready(function() 
{
	if(navigator.userAgent.indexOf("MSIE") != -1) {
		$("#temperature").css("top","3px");
	} else if(navigator.userAgent.indexOf("Firefox") != -1) {
		$("#temperature").css("top","1px");
	}
});



