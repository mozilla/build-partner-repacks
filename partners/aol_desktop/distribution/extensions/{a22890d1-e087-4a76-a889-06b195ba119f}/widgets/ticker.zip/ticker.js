String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
}

String.prototype.strip = function() {
	return this.trim().replace(/(<([^>]+)>)/ig,"").replace(/(&nbsp;)/ig, " ");
}

String.prototype.abbr = function(chars) {
	var s = this.trim();
	var words = s.split(' ');
	for (var i=0; i < words.length; i++) {		
		pos = s.length;
		s += words[i];
		if (s.length > chars) {
			s = s.substring(0, pos) + "...";
			break;
		} else if (i < words.length-1) {
			s += " ";
		}		
	}	
	return s;	
}

// called when the toolbar loads this page
function widget_onInitialize(tb) {
   ticker.init(tb);
}

// called when any prefs we are monitoring change
function widget_onPrefChange(pref, args) {
	if (pref == "ticker.collapsed") {
		ticker.check(false);
	} else if (pref == "lastupdate") {
		ticker.check(true);
	}
}

// called only if we subscribe to page load events
function widget_onPageLoad(uri, data) {

}

// called after we request the toolbar to fetch the feed data
function widget_onData(data, params) {
	
	ticker.parseData(data, params);
}


// called when a message is sent to us
function  widget_onMessage(sender, msg, data) {
	
}

var ticker = function() {
    var _width = 0;
	var _padding = 4; 
	var _toolbar;
	var _events = [];
	var _widgetId;
	var _lastUpdate = 0;
	var _headlines = [];
	var _collapsed = false;
	
// configuration
var maxheadlines = 30;
var refreshTimeout = 1000*60*10;
var refreshTimer = 0;

var sepchars = " ... ";
var headlines = [];
var inRefresh = false;
var kPadding = 6;
var ffox = (navigator.userAgent.indexOf("Firefox/") != -1) ? true : false;


	
	function getValue(pref) {	
		var val;
		var key = _widgetId + "." + pref;
		try {
			val = _toolbar.getPref(key).toString();
		} catch(e) {
			alert(key + " " + e.message)
		}
		return val;
	}
	
	function setValue(pref, val) {	
		var key = _widgetId + "." + pref;
		try {
			_toolbar.setPref(key, val);
		} catch(e) {
			alert(key + " " + e.message)
		}		
	}
	
	function getNodeValue(parent) {
		var val, i, child;
		val = "";
		for (i = 0; i < parent.length; i++) {
			child = parent[i].firstChild;
			if (child){
				if (child.nodeValue.length > 0){
					val = child.nodeValue;
					break;
				}      
			}
		}                        
		return val;
	}

	function loadFeedData(force) {	
		var timeNow = new Date();
		if (force || (timeNow > _lastUpdate + (10 * 60 * 1000))) {
			_lastUpdate = timeNow;
			var url = getValue("url");
			
			_toolbar.getData(url);			
		}
	}
	
	function resize() {
		var width = $("#background").outerWidth(true) + kPadding;	
		var height = $("#background").outerHeight(true);	
		_toolbar.resize(width,height);
	}
	
	function expand(force) {
		_collapsed = false;	
		loadFeedData(force);
		$("#container").show();	
		resize();		
	}
	
	function collapse() {
		_collapsed = true;
		controller.reset();
		$("#container").hide();
		resize();
	}
	
		
	function resetTicker(xml) {
		
		var items =  xml.getElementsByTagName('item');
		
		var ul = document.getElementById("listticker");
		ul.innerHTML = "";
		var width = document.body.offsetWidth-(kPadding*2);		
		ul.style.width = width + "px";
			
		
		for (var i = 0; i < items.length; i++) {
			if (i == maxheadlines){break;};
				
			var titles = items[i].getElementsByTagName('title');            
			var links = items[i].getElementsByTagName('link');		    
					
			var title = getNodeValue(titles); 				
			var link = getNodeValue(links); 
			
			var li = document.createElement("li");
			li.className = "roll-title";
			li.setAttribute("data-link", link);
			li.setAttribute("data-desc", title);
			li.innerHTML = title;
			
			li.onclick = function(event) {
				var item = event ? event.target : this;
				ticker.openLink(item.getAttribute("data-link"));
			}
			
			li.onmouseover = function(event) {
				var item = event ? event.target : this;
				ticker.setTooltip(event.target.getAttribute("data-desc"));
			}
			
			ul.appendChild(li);					        
		}
		
		controller.restart();
	}
		
	return {
		init : function(tb) {
		
			_toolbar = tb;
			_widgetId = tb.widget;
			
			_events["collapsed"] = _toolbar.subscribe("pref", _widgetId + ".collapsed", "collapsed");
			_width = getValue("width");
			$("#container").width(_width+"px");
			_events["width"] = _toolbar.subscribe("pref", _widgetId + ".width", _width);

			this.check(true);
		},
		
		
		check : function(force) {
			
			var col = getValue("collapsed");
			_collapsed = (col == "true");
			
			if (_collapsed) {
				collapse();
			} else {
				expand(force);
			}
		},
		
		toggle : function() {
			var val = _collapsed ? "false" : "true";			
			setValue("collapsed", val);			
		},
		
		
		
		updateTooltip : function(el) {
			var tip =  _collapsed ? "Open Ticker" : "Hide Ticker";
			_toolbar.updateTooltip(tip);			
		},
		
		setTooltip : function(tip) {
			_toolbar.updateTooltip(tip);
		},
		
		openLink : function(uri) {
			_toolbar.openUrl(uri, 2, "");
		},
		
		parseData : function (data, params) {	
			if (window.DOMParser) {
				var parser = new DOMParser();
				xml = parser.parseFromString(data,"text/xml");
			} else { // Internet Explorer
				xml = new ActiveXObject("Microsoft.XMLDOM");
				xml.async = false;
				xml.loadXML(data);
			}  
			resetTicker(xml);
		}
	}
}();



var controller = {

	stopped : true,
	timer : 0,

	
	reset : function() {	
		if (this.timer != 0) {
			clearInterval(this.timer);
			this.timer = 0;
		}
	},
	
	restart : function() {
		this.setup();
		this.roll();			
	},
	
	roll: function() {
	
		if (!controller.stopped) {
		   return ;
		}
		controller.stopped = false;
		var s = 0;
		var p = $('ul#listticker li:first').css('marginTop');
		if (p) {
			p = p.replace("px", "");
			s = p / 0.005;			
			if (s < 0) {
				s = 0;
			}
		}
		
		$('ul#listticker li:first').animate({marginTop:0}, s, function(){
			controller.reset();
			controller.timer = setInterval(controller.moveleft, 500);
		});
	},
	
	moveleft:function() {
		controller.reset();
		var ticker_Width = $('#container').width();
		var li_Width = $('ul#listticker li:first').outerWidth();
		
		var l = parseInt($('ul#listticker li:first').css('marginLeft').replace("px",""));
		var dis = li_Width - ticker_Width + 20;
		  
		var v =  (dis + l) /0.05;
		if (v < 0) { v = 0; dis =0;}
	 
		$('ul#listticker li:first').animate({marginLeft:'-'+dis}, v,  
		function() {
			 controller.reset();
			 controller.stopped = true;
			 controller.timer  = setInterval(controller.moveupagain, 500);
		   
		});
	},
	
	moveupagain:function(){	
			controller.reset();
			var li_Height = $('ul#listticker li:first').outerHeight();
			$('ul#listticker li:first').animate({marginTop:-li_Height},'slow',function(){
			    var title = $('ul#listticker li:first').html();
				var link = $('ul#listticker li:first').attr("data-link");
				var desc = $('ul#listticker li:first').attr("data-desc");
				controller.stopped = true;
				controller.reset();
				controller.timer = setInterval(controller.roll, 500);
				$(this).remove();
				controller.pivot(title, link, desc);
			});
	},

	setup:function(){
		$('#container').hover(
			function(){
				controller.reset();
				$('ul#listticker li:first').stop(true, false);
				controller.stopped = true;
			},

			function(){
				controller.reset();
				var ticker_Width = $('#container').width();
				var li_Width = $('ul#listticker li:first').outerWidth();
				var l = parseInt($('ul#listticker li:first').css('marginLeft').replace("px",""));
				var t = parseInt($('ul#listticker li:first').css('marginTop').replace("px",""));

				var dis = li_Width  - ticker_Width + 30;
				if ( l < 0 ) {
					dis = dis + l ;
				}
				controller.stopped = true;
				
				if (t < 0) {
					controller.moveupagain();
				} else if (dis >= 0) {
					controller.moveleft();
				} else {
					controller.roll();
				}
			}
		);
	
	},
	
	pivot : function(title, link, desc) {  
	
			var li = document.createElement("li");
			li.className = "roll-title";
			li.setAttribute("data-link", link);
			li.setAttribute("data-desc", desc);
			li.innerHTML = title;
			li.style.display = "none";
			li.onclick = function(event) {
				var item = event ? event.target : this;
				ticker.openLink(item.getAttribute("data-link"));
			}
			
			li.onmouseover = function(event) {
				var item = event ? event.target : this;
				ticker.setTooltip(item.getAttribute("data-desc"));
			}
	
	
			$('ul#listticker').append(li);
            $('ul#listticker li').css("margin",0);
			$('ul#listticker li:last').animate({opacity: 1}, 10).fadeIn('slow');

			
	}

};
