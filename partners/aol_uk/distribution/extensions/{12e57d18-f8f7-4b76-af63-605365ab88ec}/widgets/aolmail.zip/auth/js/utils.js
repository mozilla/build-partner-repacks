/*
 * AOL Browser Extensions
 *
 * Copyright (c) 2012 AOL.
 * All rights reserved.
 */

// -----------------------------------------------------
//                   CROSS-BROWSER
// +++++++++++++++++++++++++++++++++++++++++++++++++++++
/**
 * Trims text in str to phisical lenght less that maxPx pixels.
 * boxId must be an div element id, which has same style as measured text with
 * additional style="position: absolute; visibility: hidden; height: auto; width: auto;" applied.
 * Returns string which is less maxPx pixels width, unless a 1 char lenght string is larger then maxPx,
 * in that case a 1 char string is returned.
 * On a 1 char or empty string input, same string is returned immediately.
 * If shortenSuffix is defined, then, in case string was shortened, it's added to the end of sortened string.
 *
 * jQuery required
 */
function advShorten(boxId, newClass, str, maxPx, shortenSuffix) {
    // too short, return immediately
    if(str.length <= 1)
        return str;

    // get measure box
    var elem = document.getElementById(boxId);
    var el = $("#" + boxId);
    el.text(str);

    // original string is OK
    if(elem.clientWidth < maxPx) {
        el.removeClass(newClass);
        return str;
    }

    var suflen = 0;
    if(shortenSuffix != undefined) {
        el.text(shortenSuffix);
        suflen = elem.clientWidth;
    }

    // until last char
    while(str.length > 1) {
        // trim last char
        str = str.substring(0, str.length - 1);
        el.text(str);

        // measure with suffix added
        if(elem.clientWidth + suflen < maxPx) {
            if(suflen != 0) {
                // add suffix if present
                str = str + shortenSuffix;
            }
            el.removeClass(newClass);
            return str;
        }
    }
    el.removeClass(newClass);
    // return last char
    return str;
}

/**
 * Check if string is undefined or empty.
 */
function isUndefinedOrEmpty(str) {
    return (str == undefined) || (str == '');
}

/**
 * Check if string is undefined or whitespace.
 * jQuery required
 */
function isUndefinedOrWhitespace(str) {
    return (str == undefined) || ($.trim(str) == '');
}

function isValidURL(text) {
    if (!isUndefinedOrEmpty(text)) {
        return Boolean(text.match(/^\s*([a-z]+\:\/\/)?(\S*@)?((([^\s!@#$%^&*()_=+[\]{}\|;:'",.<>/?]+\.)+[^\s!@#$%^&*()_=+[\]{}\|;:'",.<>/?]+)|localhost)(\:\d+)?([/?#]\S*)?\s*$/i));
    }

    return false;
}

/**
 * extracts domain from a full url
 */
function getDomain(url) {
    var s = url.replace(new RegExp('http(s)?://'), '');
    var p = s.search(new RegExp('[/#?]'));
    if (p >= 0)
        s = s.substring(0, p);
    return s;
}
function cutoffHttp(url) {
    var r = new RegExp('http(s)?://');
    var s = url.replace(r, '');
    return s;
}
function getRequestParameter(name){
    if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
        return decodeURIComponent(name[1]);
}

/**
 * cleans aol username from '@aol.com'
 */
function aoluc(name) {
    var n = '@aol.com';

    if (name.match(n) != -1) {
        return name.replace(n, '');
    }
}

function shorten(str, maxlen) {
    if(str.length <= maxlen) {
        return str;
    } else {
        return str.substring(0, maxlen) + '...';
    }
}

/**
 * Get a US string presentation of the date.
 * @param date
 * @param detectToday - if the date is today, then the function returns time
 * @param locale - optional
 */
function getFormattedDate(date, detectToday, locale) {
    var day = date.getDate();
    var month = date.getMonth();// + 1;
    var year = date.getYear(); // + 1900;
    var now = new Date();
    if (detectToday == true && now.getDate() == day && now.getMonth() == month && now.getYear() == year)
        return getFormattedTime(date, locale); //"Today";
    else {
        // TODO: elaborate more...
        if (locale == undefined || locale == "en-US")
        // return US-style date
            return "" + (month + 1) + "/" + day  + "/" + (year - 100);
        else
        //if (locale == "ru")
            return "" + day + "." + (((month + 1) < 10)? ("0" + (month + 1)) : (month + 1)) + "." + (year - 100);
    }
}
/**
 * Get a string presentation of the time
 * @param date
 * @param locale - optional
 * @return {*}
 */
function getFormattedTime(date, locale) {
    if (locale == undefined || locale == "en-US") {
        var hour = date.getHours();
        var min = date.getMinutes();
        var h = hour%12;
        h = (h == 0)? 12 : h;
        return h + ":" + ((min < 10) ? ("0"+min) : min) + " " + ((hour>11) ? "pm" : "am");
    } else
        return date.toTimeString().match( /^([0-9]{2}:[0-9]{2})/ )[0];
}

// this is for debug properties only
function dumpProps(obj, parent) {
    // Go through all the properties of the passed-in object
    for (var i in obj) {
        // if a parent (2nd parameter) was passed in, then use that to
        // build the message. Message includes i (the object's property name)
        // then the object's property value on a new line
        if (parent) { var msg = parent + "." + i + "\n" + obj[i]; } else { var msg = i + "\n" + obj[i]; }
        // Display the message. If the user clicks "OK", then continue. If they
        // click "CANCEL" then quit this level of recursion
        if (!confirm(msg)) { return; }
        // If this property (i) is an object, then recursively process the object
        if (typeof obj[i] == "object") {
            if (parent) { dumpProps(obj[i], parent + "." + i); } else { dumpProps(obj[i], i); }
        }
    }
}

/*
 * Creates a url from given query string and arguments.
 *
 * Example:
 * query is http://example.com/svc
 * args is { test: 'value', lang: 'en' }
 * will result in return value http://example.com/svc?test=value&lang=en
 *
 */
function makeUrl (query, args) {
    var rv = query + '?';
    var a = [];
    var arg = undefined;
    for(arg in args) {
        if (args.hasOwnProperty(arg)) {
            a.push(arg + '=' + args[arg]);
        }
    }

    return rv + a.join('&');
}

/**
 * A shortcut to set checked/unchecked state for the checkbox
 * @param name
 * @param value
 */
function setCheckboxState(name, checked) {
    if (!checked)
        $("#" + name).removeAttr("checked");
    else
        $("#" + name).attr({checked: "checked"});
}

function parseUri(str) {
    /**
     * options for url parsing
     * TODO: move this to utils.js
     */
    var uriOptions = {
        strictMode: false,
        key: ["source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor"],
        q: {
            name: "queryKey",
            parser: /(?:^|&)([^&=]*)=?([^&]*)/g
        },
        parser: {
            strict: /^(?:([^:\/?#]+):)?(?:\/\/((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?))?((((?:[^?#\/]*\/)*)([^?#]*))(?:\?([^#]*))?(?:#(.*))?)/,
            loose: /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/
        }
    };

    var o = uriOptions,
        m = o.parser[o.strictMode ? "strict" : "loose"].exec(str),
        uri = {},
        i = 14;

    while (i--) uri[o.key[i]] = m[i] || "";

    uri[o.q.name] = {};
    uri[o.key[12]].replace(o.q.parser, function ($0, $1, $2) {
        if ($1) uri[o.q.name][$1] = $2;
    });

    return uri;
}

/*
 * Get 'name' value from 'str'
 */
function getQueryVariable(str, name) {
    var query = str;
    var vars = query.split('&');
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if (decodeURIComponent(pair[0]) == name) {
            return decodeURIComponent(pair[1]);
        }
    }

    return undefined;
}

function mt_rand (min, max) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // +   improved by: Brett Zamir (http://brett-zamir.me)
  // +   input by: Kongo
  // *     example 1: mt_rand(1, 1);
  // *     returns 1: 1
  var argc = arguments.length;
  if (argc === 0) {
    min = 0;
    max = 2147483647;
  }
  else if (argc === 1) {
    throw new Error('Warning: mt_rand() expects exactly 2 parameters, 1 given');
  }
  else {
    min = parseInt(min, 10);
    max = parseInt(max, 10);
  }
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/*
 * returns a pseudo-nonce
 */
function nonce() {
    return +mt_rand(1000000000, 2147483647);
}

/*
 * return number of seconds since 1970 (UTC?)
 */
function timestamp() {
    return Math.round(+new Date/1000);
}

function getIEVersion()
{
  var rv = -1;
  if (navigator.appName == 'Microsoft Internet Explorer')
  {
    var ua = navigator.userAgent;
    var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
    if (re.exec(ua) != null)
      rv = parseFloat( RegExp.$1 );
  }
  else if (navigator.appName == 'Netscape')
  {
    var ua = navigator.userAgent;
    var re  = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
    if (re.exec(ua) != null)
      rv = parseFloat( RegExp.$1 );
  }
  return rv;
}

