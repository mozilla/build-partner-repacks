var lid;

function widget_onInitialize(obj) {
	weather.init(obj);	
}

function widget_onPageLoad(uri, data) {
	weather.check();
}

function widget_onPrefChange(pref, data) {
	if(pref === "weather.locationid" && weather.getLocationUpdated()) {
		weather.fetch();			
	}
	weather.update();
}

// called after we request the toolbar to fetch the feed data
function widget_onData(data, params) {
	weather.parse(data, params);				
	weather.update();
}

function showHover() {
	document.getElementById("weather_left_edge").style.backgroundImage = "url('chiclet_left_weather_hover.png')";
	document.getElementById("weather_span").style.backgroundImage = "url('chiclet_tile_weather_hover.png')";
	document.getElementById("weather_right_edge").style.backgroundImage = "url('chiclet_right_weather_hover.png')";
}

function resetHover() {
	document.getElementById("weather_left_edge").style.backgroundImage = "url('chiclet_left.png')";
	document.getElementById("weather_span").style.backgroundImage = "url('chiclet_tile.png')";
	document.getElementById("weather_right_edge").style.backgroundImage = "url('chiclet_right.png')";
}


var  weather = function() {

	var _toolbar;
	var _widgetId = 0
	var _count = -1;
	var _events = [];
	var _eventID;
	var _lastUpdate;
	var updateInterval = (1000 * 60) * 15; // every 15 minutes do a re-pull

	function getValue(pref) {
		var key = _widgetId + "." + pref;
		var val = _toolbar.getPref(key);
		return val.toString();
	}

	function setValue(pref, val) {
	
		var key = _widgetId + "." + pref;
		_toolbar.setPref(key, val);
	}
	
	function getWeatherData() {
		var timeStamp = new Date().getTime();
		var url = getValue("url") + lid + "&ts=" + timeStamp;
		var timeNow = new Date();
		_lastUpdate = timeNow.getTime();
		_toolbar.getData(url);
	}

	return {
	
		init : function(tb) {
			_widgetId = tb.widget;
			_toolbar = tb;
				
			_eventId = _toolbar.subscribe("load", "page", "testing");
			_eventId = _toolbar.subscribe("pref", _widgetId + ".locationid", "");
			_eventId = _toolbar.subscribe("pref", _widgetId + ".degrees", "");
			_eventId = _toolbar.subscribe("pref", _widgetId + ".degf", "");
			_eventId = _toolbar.subscribe("pref", _widgetId + ".degc", "");
			
			document.body.onclick = function(event) {
				_toolbar.openPopup("forecast");
			}

			lid = getValue("locationid");
			
			weather.fetch();			
			
			setInterval( function() {
				weather.fetch();			
			},updateInterval);
		},
		
		getLocationUpdated : function() {
			var newLocationID = getValue("locationid");
			if(newLocationID !== lid) {
				lid = newLocationID;
				return(true);
			}
			return(false);
		},
		
		fetch : function() {
			getWeatherData();	
		},
		
		parse : function(data, params) {
			var json = $.parseJSON(data),
				feed = json.WeatherResponse.data,
				degF,
				degC,
				city,
				stateCode,
				skyDesc,
				toolTip;
				
			if(feed.skyCode != 44) {
				if (feed.dayOrNight=="D") {
					dn ="";
				} else {
					dn="_n";
				}
			}

			degF = feed.tempF;
			degC = feed.tempC;
			city = feed.cityName;
			setValue("condition", feed.skyCode + dn);
			setValue("degf", degF);
			setValue("degc", degC);
			
			if(typeof feed.stateCode !== "undefined") {
				stateCode = feed.stateCode;
			} else {
				stateCode = feed.cntryCode;
			}
			skyDesc = feed.skyDesc;
				
			toolTip = city + " , " + stateCode + " : " + skyDesc;
		
			_toolbar.updateTooltip(toolTip);
		},
		
		update : function(){
			var code = getValue("condition");
			var deg = getValue("degrees");
			var temp = getValue("deg" + deg.toLowerCase());	
			document.getElementById("condition").style.backgroundImage = "url(images/"+code + ".png)";				
			document.getElementById("temperature").innerHTML = temp + "&deg;" + deg;		
		},
	
		check : function() {
			_count++;
			if (_count == 0) {					
			
				var lasttime = parseInt(getValue("lastupdate"));
				var timeNow = new Date();
				var elapsed = ((parseInt(timeNow.getTime()) - _lastUpdate)/(1000*60))%30; // time in half hour
				if (elapsed > 1) {
					getWeatherData();
				}
				weather.update();
			} else if (_count == 5) {
				_count = -1;				
			}
		},
		
		openQAP : function(event) {
			
			_toolbar.doCommand("weather.forecast");
		}
	}


}();

// wait for the page to render
$(document).ready(function() 
{
	if(navigator.userAgent.indexOf("MSIE") != -1) {
		$("#temperature").css("top","3px");
	} else if(navigator.userAgent.indexOf("Firefox") != -1) {
		$("#temperature").css("top","1px");
	}
});



