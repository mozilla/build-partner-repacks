String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
}

String.prototype.strip = function() {
	return this.trim().replace(/(<([^>]+)>)/ig,"").replace(/(&nbsp;)/ig, " ");
}

String.prototype.abbr = function(chars) {
	var s = this.trim();
	var words = s.split(' ');
	for (var i=0; i < words.length; i++) {		
		pos = s.length;
		s += words[i];
		if (s.length > chars) {
			s = s.substring(0, pos) + "...";
			break;
		} else if (i < words.length-1) {
			s += " ";
		}		
	}	
	return s;	
}

// called when the toolbar loads this page
function widget_onInitialize(tb) {
   pinit.init(tb);
}

// called when any prefs we are monitoring change
function widget_onPrefChange(pref, args) {
}

// called only if we subscribe to page load events
function widget_onPageLoad(uri, data) {

}

// called when a message is sent to us
function  widget_onMessage(sender, msg, data) {
	
}

var pinit = function() {
    var _width = 0;
	var _padding = 4; 
	var _toolbar;
	var _events = [];
	var _widgetId;	
		
	return {
		init : function(tb) {

			_toolbar = tb;
			_widgetId = tb.widget;
		},
		
		openLink : function(uri) {
			_toolbar.openUrl(uri, 2, "");
		},
		
		processPage : function() {
			_toolbar.sendMessage(_widgetId+".content", "pinit", "{}");
			_toolbar.closeWindow();
		}
	}
}();



var controller = {

};
