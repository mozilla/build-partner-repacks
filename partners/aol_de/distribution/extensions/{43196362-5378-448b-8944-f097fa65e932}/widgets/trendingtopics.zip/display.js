var app = function() {
	var _toolbar;
	var _widgetId;
	var _tooltip;
	var _eventId;
	var timeInterval = 30 * (60 * 1000),
		timeController,
		currentButton = 1;
	
	function getValue(pref) {
	
		var val;
		var key = _widgetId + "." + pref;
		try {
			val = _toolbar.getPref(key).toString();
		} catch(e) {
			alert(key + " " + e.message)
		}
		return val;
	}
	
	function setValue(pref, val) {
	
		var key = _widgetId + "." + pref;
		try {
			_toolbar.setPref(key, val);
		} catch(e) {
			alert(key + " " + e.message)
		}
		
	}
	
	return {
        onInitialize : function(tb) {
			_toolbar = tb;
			_widgetId = tb.widget;
			if (typeof JSON != "undefined") {
				_tooltip = JSON.parse(tb.json).tooltip;
			}
			setValue("imagelist.layout","bubble1"); 
			timeController = setInterval(function() {
				if(currentButton == 1) {
					setValue("imagelist.layout","bubble2"); 
					currentButton = 2;
				} else {
					setValue("imagelist.layout","bubble3"); 
					clearInterval(timeController);
				}
			},timeInterval);
		}
	}
}();
